<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>VIP ONTHEGO</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/thecss.css" rel="stylesheet">

  </head>
  <body>
    <div class="mycontainer black-bg">
        <div class="z-row">
            <div class="vertical-center z-vh">
                <div class="col-lg-12">
                    <div class="center-block">
                        <img src="<?php echo e(asset('/')); ?>img/viplogo.png" class="img-responsive center-block">
                    <h2 class="white-f text-center">COMING SOON</h2>
                    </div>
                </div>
               
            </div>
        </div>
    </div>
  </body>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</html>